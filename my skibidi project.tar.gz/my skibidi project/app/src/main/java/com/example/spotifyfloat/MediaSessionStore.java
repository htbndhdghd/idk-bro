package com.example.spotifyfloat;

import android.media.session.MediaController;

public final class MediaSessionStore {
    private static volatile MediaController controller;
    private static volatile OverlayService overlayService;

    private MediaSessionStore() {
    }

    public static void setController(MediaController newController) {
        controller = newController;
        if (overlayService != null) {
            overlayService.refreshFromSession();
        }
    }

    public static MediaController getController() {
        return controller;
    }

    public static void attachOverlay(OverlayService service) {
        overlayService = service;
    }

    public static void detachOverlay(OverlayService service) {
        if (overlayService == service) {
            overlayService = null;
        }
    }
}
