package com.example.spotifyfloat;

import android.content.ComponentName;
import android.media.session.MediaController;
import android.media.session.MediaSessionManager;
import android.service.notification.NotificationListenerService;

import java.util.List;

public class SpotifyNotificationListener extends NotificationListenerService {
    private MediaSessionManager sessionManager;
    private final MediaSessionManager.OnActiveSessionsChangedListener sessionsListener =
            controllers -> selectSpotifySession(controllers);

    @Override
    public void onListenerConnected() {
        sessionManager = (MediaSessionManager) getSystemService(MEDIA_SESSION_SERVICE);
        selectSpotifySession(sessionManager.getActiveSessions(
                new ComponentName(this, SpotifyNotificationListener.class)));
        sessionManager.addOnActiveSessionsChangedListener(sessionsListener,
                new ComponentName(this, SpotifyNotificationListener.class));
    }

    @Override
    public void onListenerDisconnected() {
        if (sessionManager != null) {
            sessionManager.removeOnActiveSessionsChangedListener(sessionsListener);
        }
        MediaSessionStore.setController(null);
        super.onListenerDisconnected();
    }

    private void selectSpotifySession(List<MediaController> controllers) {
        for (MediaController controller : controllers) {
            if ("com.spotify.music".equals(controller.getPackageName())) {
                MediaSessionStore.setController(controller);
                return;
            }
        }
        MediaSessionStore.setController(null);
    }
}
