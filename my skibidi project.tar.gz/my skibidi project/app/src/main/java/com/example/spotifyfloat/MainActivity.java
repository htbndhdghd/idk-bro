package com.example.spotifyfloat;

import android.content.ComponentName;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    private Button overlayPermissionButton;
    private Button notificationPermissionButton;
    private Button startButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        overlayPermissionButton = findViewById(R.id.overlay_permission_button);
        notificationPermissionButton = findViewById(R.id.notification_permission_button);
        startButton = findViewById(R.id.start_button);

        overlayPermissionButton.setOnClickListener(view -> openOverlaySettings());
        notificationPermissionButton.setOnClickListener(view -> openNotificationSettings());
        startButton.setOnClickListener(view -> startOverlay());
    }

    @Override
    protected void onResume() {
        super.onResume();
        refreshStatus();
    }

    private void refreshStatus() {
        boolean overlayReady = Settings.canDrawOverlays(this);
        boolean notificationReady = isNotificationAccessEnabled();
        overlayPermissionButton.setText(overlayReady ? "Overlay permission ready" : "Display over other apps");
        notificationPermissionButton.setText(notificationReady ? "Notification access ready" : "Notification access");
        startButton.setEnabled(overlayReady && notificationReady);
        startButton.setText(overlayReady && notificationReady
                ? "Start floating control"
                : "Complete setup to start");
    }

    private void openOverlaySettings() {
        Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:" + getPackageName()));
        startActivity(intent);
    }

    private void openNotificationSettings() {
        startActivity(new Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS"));
    }

    private boolean isNotificationAccessEnabled() {
        String enabledListeners = Settings.Secure.getString(
                getContentResolver(), "enabled_notification_listeners");
        if (enabledListeners == null) {
            return false;
        }
        ComponentName component = new ComponentName(this, SpotifyNotificationListener.class);
        return enabledListeners.contains(component.flattenToString());
    }

    private void startOverlay() {
        if (!Settings.canDrawOverlays(this) || !isNotificationAccessEnabled()) {
            Toast.makeText(this, "Complete both permissions first", Toast.LENGTH_SHORT).show();
            return;
        }
        startService(new Intent(this, OverlayService.class));
        Toast.makeText(this, "Floating control started", Toast.LENGTH_SHORT).show();
    }
}
