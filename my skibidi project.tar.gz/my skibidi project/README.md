# Spotify Float

A small transparent Android overlay for Spotify playback controls.

## Build

Open this folder in Android Studio and let it install the Android Gradle Plugin dependencies. Then run the `app` configuration on an Android 8.0+ device.

On first launch:

1. Allow **Display over other apps**.
2. Allow **Spotify Float** notification access. This is needed to read Spotify's active media session.
3. Start the floating control.

The overlay is intentionally compact and can be dragged by its top bar. It follows the active Spotify media session and provides previous, play/pause, and next controls.

This app does not use Spotify account credentials or the Spotify Web API. It controls the media session already exposed by the Spotify app.
