package com.example.spotifyfloat;

import android.app.Service;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.media.session.MediaController;
import android.media.session.PlaybackState;
import android.os.IBinder;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.core.content.ContextCompat;

public class OverlayService extends Service {
    private WindowManager windowManager;
    private OverlayView overlayView;
    private MediaController.Callback mediaCallback;

    @Override
    public void onCreate() {
        super.onCreate();
        windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
        overlayView = new OverlayView();
        WindowManager.LayoutParams params = new WindowManager.LayoutParams(
                dp(292),
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT);
        params.gravity = Gravity.TOP | Gravity.CENTER_HORIZONTAL;
        params.y = dp(72);
        windowManager.addView(overlayView, params);
        MediaSessionStore.attachOverlay(this);
        refreshFromSession();
    }

    @Override
    public void onDestroy() {
        MediaController controller = MediaSessionStore.getController();
        if (controller != null && mediaCallback != null) {
            controller.unregisterCallback(mediaCallback);
        }
        MediaSessionStore.detachOverlay(this);
        if (overlayView != null) {
            windowManager.removeView(overlayView);
        }
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    public void refreshFromSession() {
        MediaController controller = MediaSessionStore.getController();
        if (mediaCallback != null && controller != null) {
            controller.unregisterCallback(mediaCallback);
        }
        if (controller != null) {
            mediaCallback = new MediaController.Callback() {
                @Override
                public void onMetadataChanged(android.media.MediaMetadata metadata) {
                    updateDetails();
                }

                @Override
                public void onPlaybackStateChanged(PlaybackState state) {
                    updateDetails();
                }
            };
            controller.registerCallback(mediaCallback);
        }
        updateDetails();
    }

    private void updateDetails() {
        if (overlayView == null) {
            return;
        }
        overlayView.post(() -> overlayView.updateFromSession(MediaSessionStore.getController()));
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    private class OverlayView extends LinearLayout {
        private final TextView title;
        private final TextView artist;
        private final TextView playPause;
        private float downX;
        private float downY;
        private int startX;
        private int startY;

        OverlayView() {
            super(OverlayService.this);
            setOrientation(VERTICAL);
            setPadding(dp(16), dp(10), dp(12), dp(10));
            setBackground(ContextCompat.getDrawable(OverlayService.this, R.drawable.panel));

            LinearLayout header = new LinearLayout(OverlayService.this);
            header.setGravity(Gravity.CENTER_VERTICAL);
            title = textView("Spotify");
            title.setTextSize(14);
            title.setTextColor(Color.rgb(23, 33, 27));
            title.setTypeface(null, android.graphics.Typeface.BOLD);
            artist = textView("Open Spotify to begin");
            artist.setTextSize(11);
            artist.setTextColor(Color.rgb(104, 115, 108));

            LinearLayout labels = new LinearLayout(OverlayService.this);
            labels.setOrientation(VERTICAL);
            labels.addView(title, new LayoutParams(0, LayoutParams.WRAP_CONTENT, 1));
            labels.addView(artist, new LayoutParams(0, LayoutParams.WRAP_CONTENT, 1));
            header.addView(labels, new LayoutParams(0, LayoutParams.WRAP_CONTENT, 1));
            TextView close = textView("x");
            close.setTextSize(16);
            close.setGravity(Gravity.CENTER);
            close.setContentDescription("Close floating control");
            close.setOnClickListener(view -> stopSelf());
            header.addView(close, new LayoutParams(dp(28), dp(32)));
            header.setOnTouchListener(this::moveOverlay);
            addView(header, new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT));

            LinearLayout controls = new LinearLayout(OverlayService.this);
            controls.setGravity(Gravity.CENTER);
            controls.setPadding(0, dp(8), 0, 0);
            TextView previous = button("<<", "Previous track");
            playPause = button(">", "Play or pause");
            TextView next = button(">>", "Next track");
            previous.setOnClickListener(view -> dispatch(MediaController.TransportControls::skipToPrevious));
            playPause.setOnClickListener(view -> togglePlayback());
            next.setOnClickListener(view -> dispatch(MediaController.TransportControls::skipToNext));
            controls.addView(previous, new LayoutParams(dp(48), dp(40)));
            controls.addView(playPause, new LayoutParams(dp(64), dp(40)));
            controls.addView(next, new LayoutParams(dp(48), dp(40)));
            addView(controls, new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT));
        }

        private TextView textView(String value) {
            TextView view = new TextView(OverlayService.this);
            view.setText(value);
            return view;
        }

        private TextView button(String label, String description) {
            TextView button = new TextView(OverlayService.this);
            button.setText(label);
            button.setTextColor(Color.WHITE);
            button.setTextSize(13);
            button.setGravity(Gravity.CENTER);
            button.setBackground(ContextCompat.getDrawable(OverlayService.this, R.drawable/action_button));
            button.setContentDescription(description);
            button.setPadding(dp(8), dp(8), dp(8), dp(8));
            return button;
        }

        private void updateFromSession(MediaController controller) {
            if (controller == null || controller.getMetadata() == null) {
                title.setText("Spotify");
                artist.setText("Open Spotify to begin");
                playPause.setText(">");
                return;
            }
            android.media.MediaMetadata metadata = controller.getMetadata();
            CharSequence track = metadata.getText(android.media.MediaMetadata.METADATA_KEY_TITLE);
            CharSequence performer = metadata.getText(android.media.MediaMetadata.METADATA_KEY_ARTIST);
            title.setText(track == null ? "Spotify" : track);
            artist.setText(performer == null ? "Playing" : performer);
            boolean playing = controller.getPlaybackState() != null
                    && controller.getPlaybackState().getState() == PlaybackState.STATE_PLAYING;
            playPause.setText(playing ? "||" : ">");
        }

        private void togglePlayback() {
            MediaController controller = MediaSessionStore.getController();
            if (controller == null) {
                return;
            }
            PlaybackState state = controller.getPlaybackState();
            if (state != null && state.getState() == PlaybackState.STATE_PLAYING) {
                controller.getTransportControls().pause();
            } else {
                controller.getTransportControls().play();
            }
        }

        private void dispatch(java.util.function.Consumer<MediaController.TransportControls> action) {
            MediaController controller = MediaSessionStore.getController();
            if (controller != null) {
                action.accept(controller.getTransportControls());
            }
        }

        private boolean moveOverlay(View view, MotionEvent event) {
            WindowManager.LayoutParams params = (WindowManager.LayoutParams) getLayoutParams();
            if (event.getAction() == MotionEvent.ACTION_DOWN) {
                downX = event.getRawX();
                downY = event.getRawY();
                startX = params.x;
                startY = params.y;
                return true;
            }
            if (event.getAction() == MotionEvent.ACTION_MOVE) {
                params.x = startX + (int) (event.getRawX() - downX);
                params.y = startY + (int) (event.getRawY() - downY);
                windowManager.updateViewLayout(this, params);
                return true;
            }
            return event.getAction() == MotionEvent.ACTION_UP;
        }
    }
}
